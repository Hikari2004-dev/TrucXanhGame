# Trúc Xanh – Đại đoàn kết dân tộc

Mở `index.html` bằng trình duyệt (Chrome/Edge) để chơi. Không cần cài đặt gì.

## Cấu trúc
- `index.html` – khung giao diện (các màn hình bắt đầu, chơi, kết thúc)
- `css/style.css` – màu sắc, bố cục (biến màu ở đầu file, mục `:root`)
- `js/questions.js` – **bộ câu hỏi**. Đáp án đúng luôn để ở vị trí đầu tiên trong `opts`.
- `js/data.js` – tên dân tộc (`NAMES`), thẻ kiến thức (`FACTS`), đường dẫn ảnh (`IMG`)
- `js/game.js` – logic trò chơi. Dòng đầu có các thông số: `TOTAL` (thời gian ván, giây), `QTIME` (giây/câu), `PAIRS` (số cặp), `REWARD` (sao mỗi câu đúng), `STREAK_N`/`BONUS` (thưởng chuỗi)
- `images/` – ảnh nền, ảnh bìa và ảnh 54 dân tộc (`images/dantoc/`)

## Bảng xếp hạng
Mặc định lưu trên trình duyệt của từng máy (localStorage). Muốn dùng chung, điền URL máy chủ vào `LEADERBOARD_URL` trong `js/game.js`.
